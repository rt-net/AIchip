var _user_interface_8c =
[
    [ "debugUI", "_user_interface_8c.html#a79d499af646fa4451b1edc01dac956d8", null ],
    [ "flashGreenLED", "_user_interface_8c.html#a5632aaf4c593feec86db5dd45f04b9dd", null ],
    [ "flashRedLED", "_user_interface_8c.html#a15a5451029098942e8c93adeaa1b42ff", null ],
    [ "getElapsedTime", "_user_interface_8c.html#a8a5eb00b14b07e1e0071e6cbebb202fe", null ],
    [ "getLeftSWcount", "_user_interface_8c.html#a8c483926268bba9b2588a89c5c147d42", null ],
    [ "getLipoVoltage", "_user_interface_8c.html#ad06e87f0860272450b695eedc189fc62", null ],
    [ "getMotorVoltage", "_user_interface_8c.html#a88a6e3563b17534c3e5b16a9b5d2acb4", null ],
    [ "getRightSWcount", "_user_interface_8c.html#afddcda2cc345e2479db8d5eea0a1790e", null ],
    [ "getStateLeftSW", "_user_interface_8c.html#aee30afc23e3ad95de08baac8cbc9138e", null ],
    [ "getStateRightSW", "_user_interface_8c.html#a9df5cde687782a18074248be28f99de5", null ],
    [ "initUI", "_user_interface_8c.html#a0e6a38adb3139816ca5ead4dfc842caa", null ],
    [ "resetElapsedTime", "_user_interface_8c.html#acb849b234132a2e710362c5222a38b60", null ],
    [ "TIMER32_0_IRQHandler", "_user_interface_8c.html#a5eac145a67d809967d2eb6ac4591b4b0", null ],
    [ "turnGreenLED", "_user_interface_8c.html#a2ffa5149729f4001be7eaf84bc236470", null ],
    [ "turnRedLED", "_user_interface_8c.html#af1a80794bf401c28dcf6880a23008c58", null ]
];