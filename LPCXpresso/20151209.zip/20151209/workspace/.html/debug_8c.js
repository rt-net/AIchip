var debug_8c =
[
    [ "myPrintfUART", "debug_8c.html#acb52286c12863b103cc835c3d8310773", null ],
    [ "myPrintfUSB", "debug_8c.html#a1bd9f450dbe5f0e704bee6a2d945822f", null ]
];