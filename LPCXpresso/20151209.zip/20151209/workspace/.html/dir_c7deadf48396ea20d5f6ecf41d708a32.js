var dir_c7deadf48396ea20d5f6ecf41d708a32 =
[
    [ "AICHIP", "dir_523dc4ab0e11c32b30adbe0ed8aaf2ea.html", "dir_523dc4ab0e11c32b30adbe0ed8aaf2ea" ],
    [ "MODE", "dir_2eff835024758b9698ff4ba14a7c8f08.html", "dir_2eff835024758b9698ff4ba14a7c8f08" ],
    [ "OTHER", "dir_cb4221f7e867e5f997e863fb5726e3ad.html", "dir_cb4221f7e867e5f997e863fb5726e3ad" ],
    [ "PERIPHERAL", "dir_c10864965aa2fb3d8fcbff2fa0ade608.html", "dir_c10864965aa2fb3d8fcbff2fa0ade608" ],
    [ "USB", "dir_4e214c49f37c1cbe169f97ce157fd84b.html", "dir_4e214c49f37c1cbe169f97ce157fd84b" ]
];