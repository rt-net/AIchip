var searchData=
[
  ['cdc_5fbuf_5ft',['CDC_BUF_T',['../cdcuser_8c.html#a83dcf9ee448cb14872b0d002b2bd8561',1,'cdcuser.c']]],
  ['cdc_5fnotification_5fheader',['CDC_NOTIFICATION_HEADER',['../cdc_8h.html#a0859cc73ebea375bd109da2f54b862cf',1,'cdc.h']]]
];
