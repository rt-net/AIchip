var searchData=
[
  ['coredebug_5ftype',['CoreDebug_Type',['../struct_core_debug___type.html',1,'']]]
];
