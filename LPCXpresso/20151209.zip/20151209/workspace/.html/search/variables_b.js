var searchData=
[
  ['notificationbuf',['NotificationBuf',['../cdcuser_8c.html#a0cd2b6a49e07831a5bc15e25878b9b97',1,'cdcuser.c']]],
  ['num',['num',['../struct_g_e_t_d_a_t___t.html#a86cf672daa4e0ad11ad10efc894d19c8',1,'GETDAT_T']]]
];
