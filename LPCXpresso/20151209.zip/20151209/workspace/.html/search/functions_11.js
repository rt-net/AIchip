var searchData=
[
  ['vcom_5fcheckstate',['VCOM_CheckState',['../usb_transmission_8h.html#a4a2bacd9a23fff588cb7f5b6538e7b25',1,'VCOM_CheckState(void):&#160;usbTransmission.c'],['../usb_transmission_8c.html#a4a2bacd9a23fff588cb7f5b6538e7b25',1,'VCOM_CheckState(void):&#160;usbTransmission.c']]],
  ['vcom_5fsenddata',['VCOM_SendData',['../usb_transmission_8h.html#a2d6d7c05d91576af25410bb856740976',1,'VCOM_SendData(GETDAT_T dat):&#160;usbTransmission.c'],['../usb_transmission_8c.html#a2d6d7c05d91576af25410bb856740976',1,'VCOM_SendData(GETDAT_T dat):&#160;usbTransmission.c']]]
];
