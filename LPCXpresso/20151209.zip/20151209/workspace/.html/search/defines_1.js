var searchData=
[
  ['bufsize',['BUFSIZE',['../i2c_8h.html#aeca034f67218340ecb2261a22c2f3dcd',1,'BUFSIZE():&#160;i2c.h'],['../uart_8h.html#aeca034f67218340ecb2261a22c2f3dcd',1,'BUFSIZE():&#160;uart.h']]]
];
