var searchData=
[
  ['ep0buf',['EP0Buf',['../usbcore_8h.html#aafa2eadf08e7256fa79dbb27cfbeeb22',1,'EP0Buf():&#160;usbcore.c'],['../usbcore_8c.html#aafa2eadf08e7256fa79dbb27cfbeeb22',1,'EP0Buf():&#160;usbcore.c']]],
  ['ep0data',['EP0Data',['../usbcore_8h.html#ae48f7fef62babbd6888b920a0d7238a6',1,'EP0Data():&#160;usbcore.c'],['../usbcore_8c.html#ae48f7fef62babbd6888b920a0d7238a6',1,'EP0Data():&#160;usbcore.c']]]
];
