var searchData=
[
  ['rdidx',['rdIdx',['../struct_____s_e_r___b_u_f___t.html#a0099fdf62afe937e9358215670b8fe10',1,'__SER_BUF_T::rdIdx()'],['../struct_____c_d_c___b_u_f___t.html#a0099fdf62afe937e9358215670b8fe10',1,'__CDC_BUF_T::rdIdx()']]],
  ['rdindex',['RdIndex',['../i2c_8c.html#a5d58180aff42f279cad5adae99aa20d1',1,'i2c.c']]],
  ['recipient',['Recipient',['../struct___r_e_q_u_e_s_t___t_y_p_e_1_1___b_m.html#a7b6d9666d052ca5299f88a48ffa7b977',1,'_REQUEST_TYPE::_BM::Recipient()'],['../struct___b_m.html#a7b6d9666d052ca5299f88a48ffa7b977',1,'_BM::Recipient()'],['../usb_8h.html#a7b6d9666d052ca5299f88a48ffa7b977',1,'Recipient():&#160;usb.h']]],
  ['reserved0',['RESERVED0',['../struct_n_v_i_c___type.html#ac881b676be4d9659951f43c2fccb34b4',1,'NVIC_Type::RESERVED0()'],['../struct_i_t_m___type.html#a498ca2f25075b26fd57d1f66d976fe8c',1,'ITM_Type::RESERVED0()'],['../struct_interrupt_type___type.html#af86c61a5d38a4fc9cef942a12744486b',1,'InterruptType_Type::RESERVED0()']]],
  ['reserved1',['RESERVED1',['../struct_i_t_m___type.html#ae5c625673da1df1777833e51754c525b',1,'ITM_Type::RESERVED1()'],['../struct_interrupt_type___type.html#ac4ac04e673b5b8320d53f7b0947db902',1,'InterruptType_Type::RESERVED1()']]],
  ['reserved2',['RESERVED2',['../struct_n_v_i_c___type.html#a86dfd6bf6c297be163d078945f67e8b6',1,'NVIC_Type::RESERVED2()'],['../struct_i_t_m___type.html#a391748a705084dd61c4a9f56d456a12c',1,'ITM_Type::RESERVED2()']]],
  ['reserved3',['RESERVED3',['../struct_n_v_i_c___type.html#a3371761ff5e69fb1b6b3c2c3b4d69b18',1,'NVIC_Type::RESERVED3()'],['../struct_i_t_m___type.html#accd35f93dc2edb52aba5af098acf5353',1,'ITM_Type::RESERVED3()']]],
  ['reserved4',['RESERVED4',['../struct_n_v_i_c___type.html#a0c75e6c517dc8e5596ffa3ef6285c232',1,'NVIC_Type::RESERVED4()'],['../struct_i_t_m___type.html#a9f5627bbbc2f2af4fdf3f6e986d7638b',1,'ITM_Type::RESERVED4()']]],
  ['reserved5',['RESERVED5',['../struct_n_v_i_c___type.html#a77017390737a14d5eb4cdb41f0aa3dce',1,'NVIC_Type::RESERVED5()'],['../struct_i_t_m___type.html#a1427341695585b4e14dc83bd6d7e2cd7',1,'ITM_Type::RESERVED5()']]],
  ['rserved1',['RSERVED1',['../struct_n_v_i_c___type.html#ab993fe7f0b489b30bc677ccf53426a92',1,'NVIC_Type']]]
];
