var searchData=
[
  ['w',['W',['../union____attribute____.html#ad1193f0da05a941478b6bb1bfc364b4a',1,'__attribute__']]],
  ['wait1msec',['wait1msec',['../_system_tick_timer_8h.html#a18af7476504a76def67727301e3968fb',1,'wait1msec(uint32_t wait_count):&#160;SystemTickTimer.c'],['../_system_tick_timer_8c.html#a18af7476504a76def67727301e3968fb',1,'wait1msec(uint32_t wait_count):&#160;SystemTickTimer.c']]],
  ['wait1usec',['wait1usec',['../_system_tick_timer_8h.html#a4c0b76146789e1b5c90418596dd38895',1,'wait1usec(uint32_t wait_count):&#160;SystemTickTimer.c'],['../_system_tick_timer_8c.html#a4c0b76146789e1b5c90418596dd38895',1,'wait1usec(uint32_t wait_count):&#160;SystemTickTimer.c']]],
  ['wbval',['WBVAL',['../usbdesc_8h.html#a018fc058eba40cffd92be1756a5d2b40',1,'usbdesc.h']]],
  ['weak',['WEAK',['../cr__startup__lpc13xx_8c.html#ad1480e9557edcc543498ca259cee6c7d',1,'cr_startup_lpc13xx.c']]],
  ['windex',['wIndex',['../struct___u_s_b___s_e_t_u_p___p_a_c_k_e_t.html#aeca4b5d6b50d0b1b2db278cb4efc0436',1,'_USB_SETUP_PACKET::wIndex()'],['../usb_8h.html#aeca4b5d6b50d0b1b2db278cb4efc0436',1,'wIndex():&#160;usb.h']]],
  ['wlength',['wLength',['../struct___u_s_b___s_e_t_u_p___p_a_c_k_e_t.html#a496c03443b177fd2e6c93616064d2934',1,'_USB_SETUP_PACKET::wLength()'],['../usb_8h.html#a496c03443b177fd2e6c93616064d2934',1,'wLength():&#160;usb.h']]],
  ['wmaxpacketsize',['wMaxPacketSize',['../struct___u_s_b___e_n_d_p_o_i_n_t___d_e_s_c_r_i_p_t_o_r.html#abcc8edb1d5094ce6a16b42c1a7ae67d8',1,'_USB_ENDPOINT_DESCRIPTOR::wMaxPacketSize()'],['../usb_8h.html#abcc8edb1d5094ce6a16b42c1a7ae67d8',1,'wMaxPacketSize():&#160;usb.h']]],
  ['wrcmd',['WrCmd',['../usbhw_8c.html#a43a57d8b8cb335d6c95b8517a46c244f',1,'usbhw.c']]],
  ['wrcmddat',['WrCmdDat',['../usbhw_8c.html#ae88115ba5c676e7d806a8062f981525a',1,'usbhw.c']]],
  ['wrcmdep',['WrCmdEP',['../usbhw_8c.html#aff86a67a8cc3b52fae0e91e96557fc60',1,'usbhw.c']]],
  ['wrdi',['WRDI',['../ssp_8h.html#acb229428140f30a6f8b6fa2ebb3fb6f0',1,'ssp.h']]],
  ['wren',['WREN',['../ssp_8h.html#a53dec1d28a7c7b24b2d56c058f7e140a',1,'ssp.h']]],
  ['wridx',['wrIdx',['../struct_____s_e_r___b_u_f___t.html#a2d456883324565b53c0f0b7ff3dac0ce',1,'__SER_BUF_T::wrIdx()'],['../struct_____c_d_c___b_u_f___t.html#a2d456883324565b53c0f0b7ff3dac0ce',1,'__CDC_BUF_T::wrIdx()']]],
  ['wrindex',['WrIndex',['../i2c_8c.html#acf833cdc9b116a31d852fb619bb2200c',1,'i2c.c']]],
  ['write',['WRITE',['../ssp_8h.html#aa10f470e996d0f51210d24f442d25e1e',1,'ssp.h']]],
  ['wrsr',['WRSR',['../ssp_8h.html#a29d01dca16eb0a060d2efd567b58b47a',1,'ssp.h']]],
  ['wtotallength',['wTotalLength',['../struct___u_s_b___c_o_n_f_i_g_u_r_a_t_i_o_n___d_e_s_c_r_i_p_t_o_r.html#a866c5d9bb8a60f25805d37b7a5b5f9e8',1,'_USB_CONFIGURATION_DESCRIPTOR::wTotalLength()'],['../usb_8h.html#a866c5d9bb8a60f25805d37b7a5b5f9e8',1,'wTotalLength():&#160;usb.h']]],
  ['wvalue',['wValue',['../struct___u_s_b___s_e_t_u_p___p_a_c_k_e_t.html#a59d9039047a52815cb1981f19634d40d',1,'_USB_SETUP_PACKET::wValue()'],['../usb_8h.html#a59d9039047a52815cb1981f19634d40d',1,'wValue():&#160;usb.h']]]
];
