var searchData=
[
  ['quicksort',['quickSort',['../tiny_math_function_8h.html#aa9043655ce2582b275428e9230738a37',1,'quickSort(int numbers[], int left, int right):&#160;tinyMathFunctions.c'],['../tiny_math_functions_8c.html#aa9043655ce2582b275428e9230738a37',1,'quickSort(int numbers[], int left, int right):&#160;tinyMathFunctions.c']]]
];
