var indexSectionsWithContent =
{
  0: "_abcdefghilmnpqrstuvw",
  1: "_cgins",
  2: "acdimpstu",
  3: "_bcdefghimnpqrstuvw",
  4: "_abcdeghilmnprstuvw",
  5: "cisu",
  6: "abcdefilmnprstuw",
  7: "c",
  8: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "全て",
  1: "データ構造",
  2: "ファイル",
  3: "関数",
  4: "変数",
  5: "型定義",
  6: "マクロ定義",
  7: "グループ",
  8: "ページ"
};

