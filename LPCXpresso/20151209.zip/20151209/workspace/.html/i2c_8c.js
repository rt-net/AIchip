var i2c_8c =
[
    [ "I2C_IRQHandler", "i2c_8c.html#a420d56f594345b56efdac63fdabf71c2", null ],
    [ "I2CEngine", "i2c_8c.html#a0036f04c55d6d2118405ca42632bdbd4", null ],
    [ "I2CInit", "i2c_8c.html#a279d004d45293dff5260643be80c1319", null ],
    [ "I2CStart", "i2c_8c.html#a7c87427cfa767315491db0a0c005ec59", null ],
    [ "I2CStop", "i2c_8c.html#a7b1d12f3a83330eda885db24a701e1b5", null ],
    [ "I2CCount", "i2c_8c.html#a77f3ee188f6a73c978cc82052307ecfd", null ],
    [ "I2CMasterBuffer", "i2c_8c.html#a766e99196841c51b7560453d06423b6a", null ],
    [ "I2CMasterState", "i2c_8c.html#af2d015836f3e51c6e119304a6940d5ee", null ],
    [ "I2CMode", "i2c_8c.html#a030cffeeebfe8d5e5a3d2849566ed47d", null ],
    [ "I2CReadLength", "i2c_8c.html#a99aaa16c53f267f8862d444f522d763c", null ],
    [ "I2CSlaveBuffer", "i2c_8c.html#a8d36144f2477482e231da2b8a14b6380", null ],
    [ "I2CSlaveState", "i2c_8c.html#add31ac27527e6965696ed348869cdeb6", null ],
    [ "I2CWriteLength", "i2c_8c.html#a6227a3e6005b75f07040af82dc4b8a6e", null ],
    [ "RdIndex", "i2c_8c.html#a5d58180aff42f279cad5adae99aa20d1", null ],
    [ "WrIndex", "i2c_8c.html#acf833cdc9b116a31d852fb619bb2200c", null ]
];