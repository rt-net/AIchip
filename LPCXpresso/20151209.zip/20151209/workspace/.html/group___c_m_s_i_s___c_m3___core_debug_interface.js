var group___c_m_s_i_s___c_m3___core_debug_interface =
[
    [ "ITM_RXBUFFER_EMPTY", "group___c_m_s_i_s___c_m3___core_debug_interface.html#gaa822cb398ee022b59e9e6c5d7bbb228a", null ],
    [ "ITM_RxBuffer", "group___c_m_s_i_s___c_m3___core_debug_interface.html#gacf1fe3063cedf11b6e6f7cb0dd7c1a51", null ]
];