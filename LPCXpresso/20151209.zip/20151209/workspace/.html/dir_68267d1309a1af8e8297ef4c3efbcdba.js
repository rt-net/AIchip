var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "AICHIP", "dir_95ee3d4ed234dd1221919408f66c24e5.html", "dir_95ee3d4ed234dd1221919408f66c24e5" ],
    [ "MODE", "dir_029ea568973a78ade9c0a3ecbb159d75.html", "dir_029ea568973a78ade9c0a3ecbb159d75" ],
    [ "OTHER", "dir_78b36095b9c8a1ebc83098f783034f03.html", "dir_78b36095b9c8a1ebc83098f783034f03" ],
    [ "PERIPHERAL", "dir_8eb6a8da60e90f3e532350c42093659e.html", "dir_8eb6a8da60e90f3e532350c42093659e" ],
    [ "USB", "dir_3a562169f315c80d2c1712637dd568c3.html", "dir_3a562169f315c80d2c1712637dd568c3" ]
];