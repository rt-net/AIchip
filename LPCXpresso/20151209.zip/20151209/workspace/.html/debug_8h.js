var debug_8h =
[
    [ "myPrintfUART", "debug_8h.html#acb52286c12863b103cc835c3d8310773", null ],
    [ "myPrintfUSB", "debug_8h.html#a1bd9f450dbe5f0e704bee6a2d945822f", null ]
];