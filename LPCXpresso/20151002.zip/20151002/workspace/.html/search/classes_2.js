var searchData=
[
  ['getdat_5ft',['GETDAT_T',['../struct_g_e_t_d_a_t___t.html',1,'']]]
];
