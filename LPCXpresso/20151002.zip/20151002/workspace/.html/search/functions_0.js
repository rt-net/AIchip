var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../union____attribute____.html#af1d916f7f6ed798dfe8fc9552963d1d3',1,'__attribute__::__attribute__()'],['../union___r_e_q_u_e_s_t___t_y_p_e.html#a938923509fdb707aeaf9fe130b994af0',1,'_REQUEST_TYPE::__attribute__()'],['../cdc_8h.html#ad0ae943d8a91add2dfebfe490b8a0432',1,'__attribute__((packed)) CDC_HEADER_DESCRIPTOR:&#160;cdc.h'],['../usb_8h.html#aa5e494e88682fc683eef5bb463cc963d',1,'__attribute__((packed)) REQUEST_TYPE:&#160;usb.h'],['../cr__startup__lpc13xx_8c.html#adce420b900676fa0caed5a713cac82fb',1,'__attribute__((section(&quot;.after_vectors&quot;))):&#160;cr_startup_lpc13xx.c']]]
];
