var searchData=
[
  ['w',['W',['../union____attribute____.html#ad1193f0da05a941478b6bb1bfc364b4a',1,'__attribute__']]],
  ['windex',['wIndex',['../struct___u_s_b___s_e_t_u_p___p_a_c_k_e_t.html#aeca4b5d6b50d0b1b2db278cb4efc0436',1,'_USB_SETUP_PACKET::wIndex()'],['../usb_8h.html#aeca4b5d6b50d0b1b2db278cb4efc0436',1,'wIndex():&#160;usb.h']]],
  ['wlength',['wLength',['../struct___u_s_b___s_e_t_u_p___p_a_c_k_e_t.html#a496c03443b177fd2e6c93616064d2934',1,'_USB_SETUP_PACKET::wLength()'],['../usb_8h.html#a496c03443b177fd2e6c93616064d2934',1,'wLength():&#160;usb.h']]],
  ['wmaxpacketsize',['wMaxPacketSize',['../struct___u_s_b___e_n_d_p_o_i_n_t___d_e_s_c_r_i_p_t_o_r.html#abcc8edb1d5094ce6a16b42c1a7ae67d8',1,'_USB_ENDPOINT_DESCRIPTOR::wMaxPacketSize()'],['../usb_8h.html#abcc8edb1d5094ce6a16b42c1a7ae67d8',1,'wMaxPacketSize():&#160;usb.h']]],
  ['wridx',['wrIdx',['../struct_____s_e_r___b_u_f___t.html#a2d456883324565b53c0f0b7ff3dac0ce',1,'__SER_BUF_T::wrIdx()'],['../struct_____c_d_c___b_u_f___t.html#a2d456883324565b53c0f0b7ff3dac0ce',1,'__CDC_BUF_T::wrIdx()']]],
  ['wrindex',['WrIndex',['../i2c_8c.html#acf833cdc9b116a31d852fb619bb2200c',1,'i2c.c']]],
  ['wtotallength',['wTotalLength',['../struct___u_s_b___c_o_n_f_i_g_u_r_a_t_i_o_n___d_e_s_c_r_i_p_t_o_r.html#a866c5d9bb8a60f25805d37b7a5b5f9e8',1,'_USB_CONFIGURATION_DESCRIPTOR::wTotalLength()'],['../usb_8h.html#a866c5d9bb8a60f25805d37b7a5b5f9e8',1,'wTotalLength():&#160;usb.h']]],
  ['wvalue',['wValue',['../struct___u_s_b___s_e_t_u_p___p_a_c_k_e_t.html#a59d9039047a52815cb1981f19634d40d',1,'_USB_SETUP_PACKET::wValue()'],['../usb_8h.html#a59d9039047a52815cb1981f19634d40d',1,'wValue():&#160;usb.h']]]
];
