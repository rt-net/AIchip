var searchData=
[
  ['ser_5fbuf_5ft',['SER_BUF_T',['../serial_8c.html#a650e52fdc560f8a1b3fd0c610a80b746',1,'serial.c']]]
];
