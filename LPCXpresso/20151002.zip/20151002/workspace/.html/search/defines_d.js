var searchData=
[
  ['true',['TRUE',['../type_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'type.h']]],
  ['tx_5finterrupt',['TX_INTERRUPT',['../uart_8h.html#a8557658113e8a497db405dac37ca0c71',1,'uart.h']]],
  ['tx_5frx_5fonly',['TX_RX_ONLY',['../ssp_8h.html#a86c7d469092336c834892a8eadf19e86',1,'ssp.h']]],
  ['txendpkt_5fint',['TxENDPKT_INT',['../usbreg_8h.html#aac7a58c35c70d08ba832d617c0d60fea',1,'usbreg.h']]]
];
