var searchData=
[
  ['time_5fcount_5fend',['time_count_end',['../_system_tick_timer_8h.html#a2e4cfc595f13e763f4ed2c3d10d95916',1,'time_count_end(void):&#160;SystemTickTimer.c'],['../_system_tick_timer_8c.html#a2e4cfc595f13e763f4ed2c3d10d95916',1,'time_count_end(void):&#160;SystemTickTimer.c']]],
  ['time_5fcount_5fstart',['time_count_start',['../_system_tick_timer_8h.html#a9a988cffc2f7143bafe418f6af919cd9',1,'time_count_start(void):&#160;SystemTickTimer.c'],['../_system_tick_timer_8c.html#a9a988cffc2f7143bafe418f6af919cd9',1,'time_count_start(void):&#160;SystemTickTimer.c']]],
  ['timer32_5f0_5firqhandler',['TIMER32_0_IRQHandler',['../_user_interface_8c.html#a5eac145a67d809967d2eb6ac4591b4b0',1,'UserInterface.c']]],
  ['timer32_5f1_5firqhandler',['TIMER32_1_IRQHandler',['../_a_i_c_h_i_p_function_8c.html#a722d97fdabdf6a349b0ad02c82da1d23',1,'AICHIPFunction.c']]],
  ['tinvsqrt',['tInvSqrt',['../tiny_math_function_8h.html#a69b7824e362296dcc7d547597cde854e',1,'tInvSqrt(float x):&#160;tinyMathFunctions.c'],['../tiny_math_functions_8c.html#a69b7824e362296dcc7d547597cde854e',1,'tInvSqrt(float x):&#160;tinyMathFunctions.c']]],
  ['tryusbconnect',['tryUSBConnect',['../usb_transmission_8h.html#a00ae3d2d42d3c1d67f8779c026b36ec9',1,'tryUSBConnect(void):&#160;usbTransmission.c'],['../usb_transmission_8c.html#a00ae3d2d42d3c1d67f8779c026b36ec9',1,'tryUSBConnect(void):&#160;usbTransmission.c']]],
  ['tsqrt',['tSqrt',['../tiny_math_function_8h.html#a61f9712d328cfc7164f4f93a3bf02d1d',1,'tSqrt(float x):&#160;tinyMathFunctions.c'],['../tiny_math_functions_8c.html#a61f9712d328cfc7164f4f93a3bf02d1d',1,'tSqrt(float x):&#160;tinyMathFunctions.c']]],
  ['turngreenled',['turnGreenLED',['../_user_interface_8h.html#a2ffa5149729f4001be7eaf84bc236470',1,'turnGreenLED(uint8_t state):&#160;UserInterface.c'],['../_user_interface_8c.html#a2ffa5149729f4001be7eaf84bc236470',1,'turnGreenLED(uint8_t state):&#160;UserInterface.c']]],
  ['turnredled',['turnRedLED',['../_user_interface_8h.html#af1a80794bf401c28dcf6880a23008c58',1,'turnRedLED(uint8_t state):&#160;UserInterface.c'],['../_user_interface_8c.html#af1a80794bf401c28dcf6880a23008c58',1,'turnRedLED(uint8_t state):&#160;UserInterface.c']]]
];
