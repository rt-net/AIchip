var searchData=
[
  ['gain_5flpf',['gain_LPF',['../mpu9150_8c.html#a78dfe60875bfa39e7a5a1922788c8887',1,'mpu9150.c']]],
  ['gain_5fstr_5flpf',['gain_str_LPF',['../mpu9150_8c.html#af14286333f51c15766ab0ce06a29b503',1,'mpu9150.c']]]
];
