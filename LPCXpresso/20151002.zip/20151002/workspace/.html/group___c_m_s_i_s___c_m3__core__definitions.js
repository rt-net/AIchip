var group___c_m_s_i_s___c_m3__core__definitions =
[
    [ "CMSIS CM3 Core Register", "group___c_m_s_i_s___c_m3__core__register.html", "group___c_m_s_i_s___c_m3__core__register" ],
    [ "CMSIS CM3 Core Function Interface", "group___c_m_s_i_s___c_m3___core___function_interface.html", null ],
    [ "CMSIS CM3 Core Debug Interface", "group___c_m_s_i_s___c_m3___core_debug_interface.html", "group___c_m_s_i_s___c_m3___core_debug_interface" ],
    [ "__CM3_CMSIS_VERSION", "group___c_m_s_i_s___c_m3__core__definitions.html#gaf888c651cd8c93fd25364f9e74306a1c", null ],
    [ "__CM3_CMSIS_VERSION_MAIN", "group___c_m_s_i_s___c_m3__core__definitions.html#gac1c1120e9fe082fac8225c60143ac79a", null ],
    [ "__CM3_CMSIS_VERSION_SUB", "group___c_m_s_i_s___c_m3__core__definitions.html#ga9ff7a998d4b8b3c87bfaca6e78607950", null ],
    [ "__CORTEX_M", "group___c_m_s_i_s___c_m3__core__definitions.html#ga63ea62503c88acab19fcf3d5743009e3", null ],
    [ "__I", "group___c_m_s_i_s___c_m3__core__definitions.html#gaf63697ed9952cc71e1225efe205f6cd3", null ],
    [ "__IO", "group___c_m_s_i_s___c_m3__core__definitions.html#gaec43007d9998a0a0e01faede4133d6be", null ],
    [ "__NVIC_PRIO_BITS", "group___c_m_s_i_s___c_m3__core__definitions.html#gae3fe3587d5100c787e02102ce3944460", null ],
    [ "__O", "group___c_m_s_i_s___c_m3__core__definitions.html#ga7e25d9380f9ef903923964322e71f2f6", null ]
];