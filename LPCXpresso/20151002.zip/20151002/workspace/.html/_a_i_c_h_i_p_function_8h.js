var _a_i_c_h_i_p_function_8h =
[
    [ "debugAICHIP", "_a_i_c_h_i_p_function_8h.html#a98e601c6cbe042f244a4715d8922e071", null ],
    [ "getDegree", "_a_i_c_h_i_p_function_8h.html#a5950f91900fdb042d2c1117d08fc896f", null ],
    [ "getDutyMotor", "_a_i_c_h_i_p_function_8h.html#a10b8de93cea8fa939e37425aeba9b359", null ],
    [ "initAICHIP", "_a_i_c_h_i_p_function_8h.html#a6adc919a1cdcc648f73433f657d2272f", null ],
    [ "isCurve", "_a_i_c_h_i_p_function_8h.html#a7afd5477ecdbb4c1f8dc0ed7176895de", null ],
    [ "isSlope", "_a_i_c_h_i_p_function_8h.html#a11ac35fcddba4622c818c39a65d7b5a3", null ],
    [ "isStop", "_a_i_c_h_i_p_function_8h.html#ad035ccd72a2ed5a3b9f0e74ac990de0a", null ],
    [ "setDegree", "_a_i_c_h_i_p_function_8h.html#afc78eb7c8d94b18eed7fc31c4459dbc1", null ],
    [ "setDutyMotor", "_a_i_c_h_i_p_function_8h.html#a16a8ac093266a9997a930691fccfc9bd", null ],
    [ "setDutyRate", "_a_i_c_h_i_p_function_8h.html#ac844c4c657c5ae28f3b55029d6617e83", null ],
    [ "setSendDataEnable", "_a_i_c_h_i_p_function_8h.html#a74ff919bbe2bc33306db409cd474705f", null ]
];