var NAVTREE =
[
  [ "RT-AICHIP-sample", "index.html", [
    [ "My Personal Index Page", "index.html", [
      [ "Introduction", "index.html#intro", null ],
      [ "Installation", "index.html#install", [
        [ "Step 1: Opening the box", "index.html#step1", null ]
      ] ]
    ] ],
    [ "モジュール", "modules.html", "modules" ],
    [ "データ構造", "annotated.html", [
      [ "データ構造", "annotated.html", "annotated_dup" ],
      [ "データ構造索引", "classes.html", null ],
      [ "データフィールド", "functions.html", [
        [ "全て", "functions.html", null ],
        [ "関数", "functions_func.html", null ],
        [ "変数", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "ファイル", null, [
      [ "ファイル一覧", "files.html", "files" ],
      [ "大域各種", "globals.html", [
        [ "全て", "globals.html", "globals_dup" ],
        [ "関数", "globals_func.html", "globals_func" ],
        [ "変数", "globals_vars.html", null ],
        [ "型定義", "globals_type.html", null ],
        [ "マクロ定義", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_a_i_c_h_i_p_function_8c.html",
"cdcuser_8h.html#a514c6123d586172d406abff1940a0591",
"group___c_m_s_i_s___c_m3___core_debug.html#gad6815d8e3df302d2f0ff2c2c734ed29a",
"group___c_m_s_i_s___c_m3___s_c_b.html#gab5ded23d2ab1d5ff7cc7ce746205e9fe",
"mode__debug_8c_source.html",
"struct___u_s_b___c_o_n_f_i_g_u_r_a_t_i_o_n___d_e_s_c_r_i_p_t_o_r.html#a5ad4440b4eb1935d66b154d274f8a272",
"usb_8h.html",
"usbhw_8c.html#a87b4006411b630cc848d30b3e8a53e34"
];

var SYNCONMSG = 'クリックで同期表示が無効になります';
var SYNCOFFMSG = 'クリックで同期表示が有効になります';