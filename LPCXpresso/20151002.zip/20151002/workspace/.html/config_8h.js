var config_8h =
[
    [ "LED_BIT", "config_8h.html#a59f4211c4d5b67972bfcf5e4c1ba17ca", null ],
    [ "LED_PORT", "config_8h.html#a663daa01e565aee93c6f20c5845b90b4", null ],
    [ "MY_VID", "config_8h.html#ab4c470c27ab9370219d51a52da182515", null ],
    [ "NXP_VID", "config_8h.html#a2db09721290517b5838bc69808d4be6c", null ],
    [ "USB_DEVICE", "config_8h.html#ab7858cae755a8a410d6495765def4daa", null ],
    [ "USB_PROD_ID", "config_8h.html#aedd6fd729658fc1d713a29bff8f62ea0", null ],
    [ "USB_VENDOR_ID", "config_8h.html#ae506cafc7291dd06cd63c9ac87c9f130", null ]
];