var _a_i_c_h_i_p_function_8c =
[
    [ "debugAICHIP", "_a_i_c_h_i_p_function_8c.html#a2671eabb816d9bfed21d20b6e811d3fb", null ],
    [ "getDegree", "_a_i_c_h_i_p_function_8c.html#a5950f91900fdb042d2c1117d08fc896f", null ],
    [ "getDutyMotor", "_a_i_c_h_i_p_function_8c.html#a10b8de93cea8fa939e37425aeba9b359", null ],
    [ "initAICHIP", "_a_i_c_h_i_p_function_8c.html#a6adc919a1cdcc648f73433f657d2272f", null ],
    [ "isCurve", "_a_i_c_h_i_p_function_8c.html#a7afd5477ecdbb4c1f8dc0ed7176895de", null ],
    [ "isSlope", "_a_i_c_h_i_p_function_8c.html#a11ac35fcddba4622c818c39a65d7b5a3", null ],
    [ "isStop", "_a_i_c_h_i_p_function_8c.html#ad035ccd72a2ed5a3b9f0e74ac990de0a", null ],
    [ "setDegree", "_a_i_c_h_i_p_function_8c.html#afc78eb7c8d94b18eed7fc31c4459dbc1", null ],
    [ "setDutyMotor", "_a_i_c_h_i_p_function_8c.html#a16a8ac093266a9997a930691fccfc9bd", null ],
    [ "setSendDataEnable", "_a_i_c_h_i_p_function_8c.html#a74ff919bbe2bc33306db409cd474705f", null ],
    [ "TIMER32_1_IRQHandler", "_a_i_c_h_i_p_function_8c.html#a722d97fdabdf6a349b0ad02c82da1d23", null ],
    [ "UARTBuffer", "_a_i_c_h_i_p_function_8c.html#aed8b6b138039a3639bbc9a0dda8d7b98", null ],
    [ "UARTCount", "_a_i_c_h_i_p_function_8c.html#ad123655eceb71e037c3a4d270ce8414a", null ]
];