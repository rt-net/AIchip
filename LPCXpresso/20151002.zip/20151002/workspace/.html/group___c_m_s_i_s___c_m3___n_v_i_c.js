var group___c_m_s_i_s___c_m3___n_v_i_c =
[
    [ "NVIC_Type", "struct_n_v_i_c___type.html", [
      [ "IABR", "struct_n_v_i_c___type.html#ac8694e172f431db09b5d570993da3917", null ],
      [ "ICER", "struct_n_v_i_c___type.html#af458bc93cfb899fc1c77c5d1f39dde88", null ],
      [ "ICPR", "struct_n_v_i_c___type.html#a8165d9a8c0090021e56bbe91c2c44667", null ],
      [ "IP", "struct_n_v_i_c___type.html#a38c377984f751265667317981f101bb4", null ],
      [ "ISER", "struct_n_v_i_c___type.html#a0bf79013b539f9f929c75bd50f8ec67d", null ],
      [ "ISPR", "struct_n_v_i_c___type.html#ab39acf254b485e3ad71b18aa9f1ca594", null ],
      [ "RESERVED0", "struct_n_v_i_c___type.html#ac881b676be4d9659951f43c2fccb34b4", null ],
      [ "RESERVED2", "struct_n_v_i_c___type.html#a86dfd6bf6c297be163d078945f67e8b6", null ],
      [ "RESERVED3", "struct_n_v_i_c___type.html#a3371761ff5e69fb1b6b3c2c3b4d69b18", null ],
      [ "RESERVED4", "struct_n_v_i_c___type.html#a0c75e6c517dc8e5596ffa3ef6285c232", null ],
      [ "RESERVED5", "struct_n_v_i_c___type.html#a77017390737a14d5eb4cdb41f0aa3dce", null ],
      [ "RSERVED1", "struct_n_v_i_c___type.html#ab993fe7f0b489b30bc677ccf53426a92", null ],
      [ "STIR", "struct_n_v_i_c___type.html#a471c399bb79454dcdfb342a31a5684ae", null ]
    ] ]
];